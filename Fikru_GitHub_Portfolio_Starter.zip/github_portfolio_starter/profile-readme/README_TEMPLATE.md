# Fikru Debebe Mekonnen

Public Health Informatics | Healthcare Interoperability | Epidemiology | Laboratory Science

Based in Atlanta, Georgia. I work at the intersection of public health information standards, immunization data exchange, and data quality.

### Professional areas
- HL7 v2.5.1 immunization messaging and IIS implementation-guide review
- NIST IGAMT, vaccine terminology, and USCDI-related data standardization
- Public health surveillance, DHIS2, REDCap and Power BI reporting
- Laboratory quality assurance and epidemiology

### Portfolio projects
- **Immunization HL7 v2.5.1 — Data Quality Learning Demo** (add repository URL after publishing): Small, synthetic-data Python exercise exploring message structure and issue reporting. Educational; not an official validation tool.

### About this profile
This profile documents my professional domain expertise and ongoing technical learning. I distinguish professional experience from training projects and use synthetic or public data only. I do not publish employer-confidential information or patient data.

### Connect
- [LinkedIn](https://www.linkedin.com/in/fikru-mekonnen-b51b4493/)
