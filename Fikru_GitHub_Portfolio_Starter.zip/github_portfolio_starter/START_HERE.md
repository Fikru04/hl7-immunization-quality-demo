# Getting started with your GitHub portfolio

1. Register or sign in at https://github.com. Choose a professional username; no account has been created by this package.
2. Create a **public** repository named `hl7-immunization-quality-demo` at https://github.com/new. Avoid checking "Add README" because this package already includes one.
3. Extract this ZIP. Upload the **contents** of the `hl7-immunization-quality-demo` folder to the repository using **Add file → Upload files**. Keep the folder structure shown in the ZIP.
4. Before publishing, open `README.md` and review every description for accuracy. The code was prepared with AI assistance: don't claim professional Python development experience.
5. Try the script locally using the commands in the README and complete `docs/lessons_learned.md` in your own words.
6. Optional: create a separate public repository whose name exactly matches your GitHub username and use `profile-readme/README_TEMPLATE.md` as its root `README.md` to display it on your GitHub profile.
7. When your GitHub profile exists, the GitHub URL for a job application is `https://github.com/YOUR-USERNAME` (replace with the real username). Do not paste a placeholder URL into a job form.
8. Never upload confidential CDC materials, internal issue trackers, restricted documents, actual HL7 messages containing PHI, employer-owned code, passwords, or credentials.

The job application GitHub field shown in your screenshot is optional; leaving it blank is preferable to linking an unfinished profile.
